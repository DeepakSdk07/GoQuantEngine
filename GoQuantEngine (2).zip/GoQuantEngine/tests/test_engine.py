import pytest
from decimal import Decimal
from app.engine import MatchingEngine

@pytest.mark.asyncio
async def test_limit_match_partial():
    me = MatchingEngine()
    r1 = await me.submit_order("TST", "limit", "sell", Decimal("1"), Decimal("100"))
    assert r1["status"] == "accepted"
    r2 = await me.submit_order("TST", "market", "buy", Decimal("0.5"))
    assert r2["status"] == "accepted"
    assert len(r2["trades"]) == 1
    assert r2["trades"][0]["quantity"] == "0.5"

@pytest.mark.asyncio
async def test_fok_kill():
    me = MatchingEngine()
    await me.submit_order("TST", "limit", "sell", Decimal("1"), Decimal("100"))
    r = await me.submit_order("TST", "fok", "buy", Decimal("2"))
    assert r["status"] == "killed"
