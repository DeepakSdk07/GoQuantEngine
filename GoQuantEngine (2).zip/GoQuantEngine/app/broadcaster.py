import asyncio
from typing import Set
from fastapi import WebSocket

class Broadcaster:
    def __init__(self):
        self._conns: Set[WebSocket] = set()
        self._lock = asyncio.Lock()

    async def connect(self, ws: WebSocket):
        await ws.accept()
        async with self._lock:
            self._conns.add(ws)

    async def disconnect(self, ws: WebSocket):
        async with self._lock:
            if ws in self._conns:
                self._conns.remove(ws)
                try:
                    await ws.close()
                except Exception:
                    pass

    async def broadcast_json(self, payload):
        async with self._lock:
            conns = list(self._conns)
        for ws in conns:
            try:
                await ws.send_json(payload)
            except Exception:
                await self.disconnect(ws)
