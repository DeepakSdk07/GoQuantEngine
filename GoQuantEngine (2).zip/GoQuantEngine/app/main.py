from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from decimal import Decimal
from typing import Optional

from .models import OrderRequest
from .engine import MatchingEngine
from .broadcaster import Broadcaster

app = FastAPI(title="GoQuant REG-NMS Matching Engine Demo")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

engine = MatchingEngine()
market_broadcaster = Broadcaster()
trade_broadcaster = Broadcaster()

# register callbacks so engine can push updates
async def md_cb(payload):
    await market_broadcaster.broadcast_json({"type": "l2_update", "data": payload})

async def trade_cb(payload):
    await trade_broadcaster.broadcast_json({"type": "trade", "data": payload})

engine.register_marketdata_callback(md_cb)
engine.register_trade_callback(trade_cb)

@app.get("/")
async def root():
    return {"message": "Welcome to GoQuant Matching Engine API! Use /docs to test endpoints."}

@app.post("/order")
async def submit_order(req: OrderRequest):
    res = await engine.submit_order(symbol=req.symbol, order_type=req.order_type, side=req.side, quantity=req.quantity, price=req.price)
    return res

@app.get("/orderbook/{symbol}")
async def get_book_snapshot(symbol: str, depth: int = 10):
    book = engine._get_book(symbol)
    async with book.lock:
        snap = book.snapshot_top(depth)
    return snap

@app.websocket("/ws/marketdata")
async def ws_marketdata(ws: WebSocket):
    await market_broadcaster.connect(ws)
    try:
        while True:
            # keep connection alive; client can send pings
            await ws.receive_text()
    except WebSocketDisconnect:
        await market_broadcaster.disconnect(ws)

@app.websocket("/ws/trades")
async def ws_trades(ws: WebSocket):
    await trade_broadcaster.connect(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        await trade_broadcaster.disconnect(ws)
