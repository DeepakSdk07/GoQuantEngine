from decimal import Decimal

def d2s(d: Decimal | None) -> str | None:
    if d is None:
        return None
    return format(d.normalize(), 'f')
