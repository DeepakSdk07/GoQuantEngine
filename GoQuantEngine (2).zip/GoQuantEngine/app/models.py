from pydantic import BaseModel, Field, validator
from typing import Optional, Literal, List
from decimal import Decimal

OrderSide = Literal["buy", "sell"]
OrderType = Literal["market", "limit", "ioc", "fok"]

class OrderRequest(BaseModel):
    symbol: str = Field(..., example="BTC-USDT")
    order_type: OrderType
    side: OrderSide
    quantity: Decimal
    price: Optional[Decimal] = None

    @validator("quantity")
    def positive_qty(cls, v):
        if v <= 0:
            raise ValueError("quantity must be positive")
        return v

    @validator("price")
    def price_for_limit(cls, v, values):
        if values.get("order_type") == "limit" and v is None:
            raise ValueError("price required for limit orders")
        return v

class OrderResponse(BaseModel):
    order_id: str
    status: str

class L2Snapshot(BaseModel):
    timestamp: str
    symbol: str
    asks: List[List[str]]
    bids: List[List[str]]
    best_bid: Optional[str]
    best_ask: Optional[str]

class TradeReport(BaseModel):
    timestamp: str
    symbol: str
    trade_id: str
    price: str
    quantity: str
    aggressor_side: OrderSide
    maker_order_id: str
    taker_order_id: str
