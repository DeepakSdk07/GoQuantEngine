from collections import deque, defaultdict
from decimal import Decimal, getcontext
from typing import Dict, Deque, List, Optional, Tuple
from uuid import uuid4
from datetime import datetime
import asyncio
from .utils import d2s

getcontext().prec = 28

class Order:
    def __init__(self, symbol: str, order_type: str, side: str, quantity: Decimal, price: Optional[Decimal] = None):
        self.id = str(uuid4())
        self.symbol = symbol
        self.order_type = order_type
        self.side = side
        self.price = Decimal(price) if price is not None else None
        self.quantity = Decimal(quantity)
        self.remaining = Decimal(quantity)
        self.timestamp = datetime.utcnow()

    def to_dict(self):
        return {
            "id": self.id,
            "symbol": self.symbol,
            "order_type": self.order_type,
            "side": self.side,
            "price": d2s(self.price),
            "quantity": d2s(self.quantity),
            "remaining": d2s(self.remaining),
            "timestamp": self.timestamp.isoformat() + "Z"
        }

class Trade:
    def __init__(self, symbol: str, price: Decimal, quantity: Decimal, aggressor_side: str, maker_order_id: str, taker_order_id: str):
        self.trade_id = str(uuid4())
        self.symbol = symbol
        self.price = Decimal(price)
        self.quantity = Decimal(quantity)
        self.aggressor_side = aggressor_side
        self.maker_order_id = maker_order_id
        self.taker_order_id = taker_order_id
        self.timestamp = datetime.utcnow()

    def to_dict(self):
        return {
            "timestamp": self.timestamp.isoformat() + "Z",
            "symbol": self.symbol,
            "trade_id": self.trade_id,
            "price": d2s(self.price),
            "quantity": d2s(self.quantity),
            "aggressor_side": self.aggressor_side,
            "maker_order_id": self.maker_order_id,
            "taker_order_id": self.taker_order_id
        }

class OrderBook:
    def __init__(self, symbol: str):
        self.symbol = symbol
        self.bids: Dict[Decimal, Deque[Order]] = defaultdict(deque)  # price -> deque (FIFO)
        self.asks: Dict[Decimal, Deque[Order]] = defaultdict(deque)
        self.bid_prices: List[Decimal] = []  # sorted desc
        self.ask_prices: List[Decimal] = []  # sorted asc
        self.order_index: Dict[str, Tuple[str, Decimal]] = {}  # order_id -> (side, price)
        self.lock = asyncio.Lock()

    def _insert_price(self, price_list: List[Decimal], price: Decimal, descending: bool = False):
        import bisect
        if price in price_list:
            return
        if descending:
            # keep descending sort
            pos = bisect.bisect_left([-p for p in price_list], -price)
            price_list.insert(pos, price)
        else:
            pos = bisect.bisect_left(price_list, price)
            price_list.insert(pos, price)

    def _remove_price_if_empty(self, price_list: List[Decimal], mapping: Dict[Decimal, Deque[Order]], price: Decimal):
        if price in mapping and len(mapping[price]) == 0:
            del mapping[price]
            try:
                price_list.remove(price)
            except ValueError:
                pass

    def best_bid(self) -> Optional[Decimal]:
        return self.bid_prices[0] if self.bid_prices else None

    def best_ask(self) -> Optional[Decimal]:
        return self.ask_prices[0] if self.ask_prices else None

    async def add_resting_order(self, order: Order):
        if order.side == "buy":
            self._insert_price(self.bid_prices, order.price, descending=True)
            self.bids[order.price].append(order)
            self.order_index[order.id] = ("buy", order.price)
        else:
            self._insert_price(self.ask_prices, order.price, descending=False)
            self.asks[order.price].append(order)
            self.order_index[order.id] = ("sell", order.price)

    async def cancel_order(self, order_id: str) -> bool:
        if order_id not in self.order_index:
            return False
        side, price = self.order_index[order_id]
        mapping = self.bids if side == "buy" else self.asks
        dq = mapping.get(price)
        if not dq:
            return False
        for idx, o in enumerate(dq):
            if o.id == order_id:
                dq.remove(o)
                del self.order_index[order_id]
                if len(dq) == 0:
                    if side == "buy":
                        self._remove_price_if_empty(self.bid_prices, self.bids, price)
                    else:
                        self._remove_price_if_empty(self.ask_prices, self.asks, price)
                return True
        return False

    async def _match_against_book(self, incoming: Order) -> List[Trade]:
        trades: List[Trade] = []
        remaining = incoming.remaining

        if incoming.side == "buy":
            # match against asks (lowest ask price first)
            while remaining > 0 and self.ask_prices:
                best_price = self.ask_prices[0]
                # limit order should not cross worse price
                if incoming.order_type == "limit" and incoming.price is not None and incoming.price < best_price:
                    break
                dq = self.asks[best_price]
                while remaining > 0 and dq:
                    maker = dq[0]
                    trade_qty = min(remaining, maker.remaining)
                    trade_price = maker.price
                    t = Trade(symbol=incoming.symbol, price=trade_price, quantity=trade_qty,
                              aggressor_side=incoming.side, maker_order_id=maker.id, taker_order_id=incoming.id)
                    trades.append(t)
                    maker.remaining -= trade_qty
                    remaining -= trade_qty
                    incoming.remaining -= trade_qty
                    if maker.remaining == 0:
                        dq.popleft()
                        if maker.id in self.order_index:
                            del self.order_index[maker.id]
                if not dq:
                    del self.asks[best_price]
                    self.ask_prices.pop(0)
        else:
            # incoming sell -> match against bids (highest bid first)
            while remaining > 0 and self.bid_prices:
                best_price = self.bid_prices[0]
                if incoming.order_type == "limit" and incoming.price is not None and incoming.price > best_price:
                    break
                dq = self.bids[best_price]
                while remaining > 0 and dq:
                    maker = dq[0]
                    trade_qty = min(remaining, maker.remaining)
                    trade_price = maker.price
                    t = Trade(symbol=incoming.symbol, price=trade_price, quantity=trade_qty,
                              aggressor_side=incoming.side, maker_order_id=maker.id, taker_order_id=incoming.id)
                    trades.append(t)
                    maker.remaining -= trade_qty
                    remaining -= trade_qty
                    incoming.remaining -= trade_qty
                    if maker.remaining == 0:
                        dq.popleft()
                        if maker.id in self.order_index:
                            del self.order_index[maker.id]
                if not dq:
                    del self.bids[best_price]
                    self.bid_prices.pop(0)
        return trades

    async def _total_available_for_fok(self, incoming: Order) -> Decimal:
        total = Decimal(0)
        if incoming.side == "buy":
            for p in self.ask_prices:
                if incoming.order_type == "limit" and incoming.price is not None and p > incoming.price:
                    break
                dq = self.asks.get(p, [])
                for o in dq:
                    total += o.remaining
                    if total >= incoming.quantity:
                        return total
        else:
            for p in self.bid_prices:
                if incoming.order_type == "limit" and incoming.price is not None and p < incoming.price:
                    break
                dq = self.bids.get(p, [])
                for o in dq:
                    total += o.remaining
                    if total >= incoming.quantity:
                        return total
        return total

    def snapshot_top(self, depth: int = 10):
        asks = []
        bids = []
        for p in self.ask_prices[:depth]:
            qty = sum(o.remaining for o in self.asks[p])
            asks.append([d2s(p), d2s(qty)])
        for p in self.bid_prices[:depth]:
            qty = sum(o.remaining for o in self.bids[p])
            bids.append([d2s(p), d2s(qty)])
        return {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "symbol": self.symbol,
            "asks": asks,
            "bids": bids,
            "best_bid": d2s(self.best_bid()) if self.best_bid() is not None else None,
            "best_ask": d2s(self.best_ask()) if self.best_ask() is not None else None
        }

class MatchingEngine:
    def __init__(self):
        self.books: Dict[str, OrderBook] = {}
        self.marketdata_callbacks = []
        self.trade_callbacks = []

    def _get_book(self, symbol: str) -> OrderBook:
        if symbol not in self.books:
            self.books[symbol] = OrderBook(symbol)
        return self.books[symbol]

    def register_marketdata_callback(self, cb):
        self.marketdata_callbacks.append(cb)

    def register_trade_callback(self, cb):
        self.trade_callbacks.append(cb)

    async def _emit_marketdata(self, book: OrderBook):
        payload = book.snapshot_top()
        for cb in self.marketdata_callbacks:
            await cb(payload)

    async def _emit_trades(self, trades: List[Trade]):
        for t in trades:
            payload = t.to_dict()
            for cb in self.trade_callbacks:
                await cb(payload)

    async def submit_order(self, symbol: str, order_type: str, side: str, quantity: Decimal, price: Optional[Decimal] = None):
        book = self._get_book(symbol)
        order = Order(symbol=symbol, order_type=order_type, side=side, quantity=quantity, price=price)
        async with book.lock:
            # FOK pre-check: ensure full fill is possible under price constraints
            if order.order_type == "fok":
                available = await book._total_available_for_fok(order)
                if available < order.quantity:
                    # cannot fill fully -> killed
                    await self._emit_marketdata(book)
                    return {"status": "killed", "order_id": order.id, "trades": []}

            trades: List[Trade] = []
            # match for market/limit/ioc/fok
            if order.order_type in ("market", "limit", "ioc", "fok"):
                t = await book._match_against_book(order)
                trades.extend(t)

            # rest leftover only for limit orders
            if order.remaining > 0:
                if order.order_type == "limit":
                    await book.add_resting_order(order)
                

            
            if trades:
                await self._emit_trades(trades)
            await self._emit_marketdata(book)
            return {"status": "accepted", "order_id": order.id, "trades": [t.to_dict() for t in trades]}
